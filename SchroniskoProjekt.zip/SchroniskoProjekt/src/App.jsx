import './App.css'

function App() {

  const petData = [
    {id: 1, species: "ryba", name: "Dmitri", age: 15, weight: 180},
    {id: 2, species: "dinozaur", name: "Cwaniak", age: 34, weight: 350},
    {id: 3, species: "kot", name: "Cymbał", age: 7, weight: 13},
    {id: 4, species: "wąż", name: "Gryzoń", age: 3, weight: 35},
    {id: 5, species: "kapibara", name: "Jumanji", age: 40, weight: 2},
    {id: 6, species: "koń", name: "Rysiek", age: 10, weight: 602}
  ]


  return (
    <>
    <h1>Lista zwierząt do adopcji</h1>
    {petsData.map((pet) => (
      <petCard key={petID}></petCard>
    ))}
    </>
  )
}

export default App
