import "PetCard.css"



function petCard () {
const petID = petData.id
const petSpecies = petData.species 
const petName = petData.name
const petAge = petData.age 
const petWeight = petData.weight 

const petData = [
    {id: 1, species: "ryba", name: "Dmitri", age: 15, weight: 180},
    {id: 2, species: "dinozaur", name: "Cwaniak", age: 34, weight: 350},
    {id: 3, species: "kot", name: "Cymbał", age: 7, weight: 13},
    {id: 4, species: "wąż", name: "Gryzoń", age: 3, weight: 35},
    {id: 5, species: "kapibara", name: "Jumanji", age: 40, weight: 2},
    {id: 6, species: "koń", name: "Rysiek", age: 10, weight: 602}
  ]

    return (

        <>
        <div>
            Numer zwierzaka: {petID}
            Nazwa zwierzaka: {petName}
            Gatunek zwierzaka: {petSpecies}
            Wiek zwierzaka: {petAge}
            Waga zwierzaka: {petWeight}
        </div>
        </>
    );
}